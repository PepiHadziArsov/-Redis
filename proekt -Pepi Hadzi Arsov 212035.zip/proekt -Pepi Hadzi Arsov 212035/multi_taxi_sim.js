const WebSocket = require('ws');

function randOffset() { return (Math.random()-0.5)*0.01; }

function createTaxi(id, lat, lon) {
    const ws = new WebSocket('ws://localhost:8080');
    let curLat = lat, curLon = lon;
    // pick random destination within radius
    function pickDest(){
        return { lat: lat + (Math.random()-0.5)*0.02, lon: lon + (Math.random()-0.5)*0.02 };
    }
    let dest = pickDest();
    let speed = 30 + Math.random()*30; // km/h
    let status = 'enroute';

    function distanceKm(a,b,c,d){
        const R=6371;
        const toRad = v=>v*Math.PI/180;
        const dLat = toRad(c-a);
        const dLon = toRad(d-b);
        const A = Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(toRad(a))*Math.cos(toRad(c))*Math.sin(dLon/2)*Math.sin(dLon/2);
        const C = 2*Math.atan2(Math.sqrt(A), Math.sqrt(1-A));
        return R*C;
    }

    ws.on('open', ()=>{
        console.log(id, 'connected');
        setInterval(()=>{
            // move towards dest a bit based on speed and tick duration (1.5s)
            const d = distanceKm(curLat, curLon, dest.lat, dest.lon);
            if(d < 0.02){ // reached, pick new dest after idle
                status = 'idle';
                setTimeout(()=>{
                    dest = pickDest();
                    speed = 20 + Math.random()*40;
                    status = 'enroute';
                }, 2000 + Math.random()*5000);
            } else {
                // fraction of distance to move this tick
                // speed km/h => km per 1.5s = speed*(1/3600)*1.5
                const kmPerTick = speed*(1/3600)*1.5;
                const frac = Math.min(1, kmPerTick / d);
                curLat = curLat + (dest.lat - curLat)*frac;
                curLon = curLon + (dest.lon - curLon)*frac;
            }

            const payload = {
                id: id,
                lat: curLat,
                lon: curLon,
                ts: Date.now(),
                dest: dest,
                speed: speed,
                status: status
            };
            const msg = { type: 'update', payload: payload };
            ws.send(JSON.stringify(msg));
            //console.log('sent', id, payload);
        }, 1500);
    });
}

createTaxi('Taxi-1', 41.9973, 21.4280);
createTaxi('Taxi-2', 41.9990, 21.4300);
createTaxi('Taxi-3', 41.9950, 21.4260);
createTaxi('Taxi-4', 41.9930, 21.4320);
createTaxi('Taxi-5', 41.9965, 21.4210);

createTaxi('Taxi-6', 41.9980, 21.4250);
createTaxi('Taxi-7', 41.9940, 21.4290);
createTaxi('Taxi-8', 41.9995, 21.4310);
createTaxi('Taxi-9', 41.9978, 21.4230);
createTaxi('Taxi-10', 41.9955, 21.4270);
