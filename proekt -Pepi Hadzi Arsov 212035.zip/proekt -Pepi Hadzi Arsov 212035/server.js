const { WebSocketServer } = require("ws");
const redis = require("redis");

const client = redis.createClient();
client.on('error', (err) => console.error('Redis Client Error', err));
client.connect().then(()=>console.log("Redis connected")).catch(console.error);

const wss = new WebSocketServer({ port: 8080 });
console.log("Server on ws://localhost:8080 (redis-backed)");

const maxHistory = 200;

async function loadAllTaxis(){
    const ids = await client.sMembers("taxis");
    const out = {};
    for(const id of ids){
        const histRaw = await client.lRange(`taxi:${id}:history`, 0, -1);
        const metaRaw = await client.hGetAll(`taxi:${id}:meta`);
        const history = histRaw.map(x=>JSON.parse(x));
        const meta = metaRaw;
        if(meta.dest) {
            try { meta.dest = JSON.parse(meta.dest); } catch(e) {}
        }
        out[id] = { history, meta };
    }
    return out;
}

async function saveUpdate(p){
    await client.sAdd("taxis", p.id);
    await client.rPush(`taxi:${p.id}:history`, JSON.stringify({lat:p.lat, lon:p.lon, ts:p.ts}));
    const len = await client.lLen(`taxi:${p.id}:history`);
    if(len > maxHistory){
        await client.lPop(`taxi:${p.id}:history`);
    }
    await client.hSet(`taxi:${p.id}:meta`, {
        dest: JSON.stringify(p.dest || ""),
        status: p.status || ""
    });
}

function broadcast(obj){
    const msg = JSON.stringify(obj);
    wss.clients.forEach(c=>{ if(c.readyState===1) c.send(msg); });
}

wss.on("connection", async (ws)=>{
    const snapshot = { type:"snapshot", taxis: await loadAllTaxis() };
    ws.send(JSON.stringify(snapshot));

    ws.on("message", async (msg)=>{
        try{
            const data = JSON.parse(msg.toString());
            if(data.type==="update"){
                const p = data.payload;
                await saveUpdate(p);
                broadcast({ type:"update", payload:p });
            }
        }catch(e){ console.error(e); }
    });
});
